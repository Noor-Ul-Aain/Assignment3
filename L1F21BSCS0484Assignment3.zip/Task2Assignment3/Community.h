#pragma once
#include<iostream>
using namespace std;

class communityMembers //parent class
{
protected:
	char* name;
	int age;
};
class employee : public communityMembers //single inheritance of parent class
{
public:
	void employeeDisplay()
	{
		cout << "Name of employee: " << name << "\nAge of employee: " << age << endl << endl;
	}
};

class faculty : public employee //single inheritance of employee class
{
public:
	void facultyDisplay()
	{
		cout << "\nName of faculty member: " << name << "\nAge of faculty member: " << age << endl;
	}
};
class administrator : public faculty //single inheritance of faculty class
{
public:
	void adminDisplay()
	{
		cout << "\nName of administrator: " << name << "\nAge of administrator: " << age << endl;
	}
};
class teacher : public faculty //single inheritance of faculty class
{
public:
	void teacherDisplay()
	{
		cout << "\nName of teacher: " << name << "\nAge of teacher: " << age << endl;
	}
};
//class administratorTeacher : virtual public administrator, virtual public teacher //multiple inheritance of child classes (2) of faculty class
//{
//public:
//	void adminTeacherDisplay()
//	{
//		cout << "\nName of administratorTeachere: " << name << "\nAge of administratorTeacher: " << age << endl;
//	}
//};

class staff : public employee //single inheritance of employee class
{
public:
	void staffDisplay()
	{
		cout << "\nName of staff member: " << name << "\nAge of staff member: " << age << endl;
	}
};

class student : public communityMembers //single inheritance of parent class
{
public:
	void studentDisplay()
	{
		cout << "\nName of student: " << name << "\nAge of student: " << age << endl;
	}

};

class undergraduates : public student //single inheritance of student class
{
public:
	void undergraduateDisplay()
	{
		cout << "\nName of undergraduate student: " << name << "\nAge of undergraduate student: " << age << endl;
	}
};
class freshmen : public undergraduates //single inheritance of undergraduate class
{
public:
	void freshmenDisplay()
	{
		cout << "\nName of undergraduate freshmen student: " << name << "\nAge of undergraduate freshmen student: " << age << endl;
	}
};
class sophomores : public undergraduates //single inheritance of undergraduate class
{
public:
	void sophomoresDisplay()
	{
		cout << "\nName of undergraduate sophomore student: " << name << "\nAge of undergraduate sophomore student: " << age << endl;
	}
};
class juniors : public undergraduates //single inheritance of undergraduate class
{
public:
	void juniorsDisplay()
	{
		cout << "\nName of undergraduate junior student: " << name << "\nAge of undergraduate junior student: " << age << endl;
	}
};
class seniors : public undergraduates //single inheritance of undergraduate class
{
public:
	void seniorDisplay()
	{
		cout << "\nName of undergraduate senior student: " << name << "\nAge of undergraduate senior student: " << age << endl;
	}
};

class graduates : public student //single inheritance of student class
{
public:
	void graduatesDisplay()
	{
		cout << "\nName of graduate student: " << name << "\nAge of graduate student: " << age << endl;
	}
};
class PHDstudents : public graduates //single inheritance of graduates class
{
public:
	void phdDisplay()
	{
		cout << "\nName of phd student: " << name << "\nAge of phd student: " << age << endl;
	}
};
class mastersStudents : public graduates //single inheritance of graduates class
{
public:
	void mastersDisplay()
	{
		cout << "\nName of masters student: " << name << "\nAge of masters student: " << age << endl;
	}
};

class alumni : public communityMembers //single inheritance of parent class
{
public:
	void alumniDisplay()
	{
		cout << "\nName of alumni: " << name << "\nAge of alumni: " << age << endl;
	}
};