#include"Community.h"

int main()
{
	const int size = 40;
	char* name = new char[size];
	int age = 0;

	employee obj;
	cout << "Enter name of an employe: ";
	cin >> name;
	cout << "Enter age of an employee: ";
	cin >> age;
	obj.employeeDisplay();

	faculty obj1;
	cout << "Enter name of faculty member: ";
	cin >> name;
	cout << "Enter age of faculty member: ";
	cin >> age;
	obj1.facultyDisplay();

	administrator obj2;
	cout << "Enter name of an administrator: ";
	cin >> name;
	cout << "Enter age of an administrator: ";
	cin >> age;
	obj2.adminDisplay();

	teacher obj3;
	cout << "Enter name of teacher: ";
	cin >> name;
	cout << "Enter age of teacher: ";
	cin >> age;
	obj3.teacherDisplay();

	/*administratorTeacher obj4;
	cout << "Enter name of an administratorTeacher: ";
	cin >> name;
	cout << "Enter age of an administratorTeacher: ";
	cin >> age;
	obj4.adminTeacherDisplay();*/

	staff obj5;
	cout << "Enter name of staff: ";
	cin >> name;
	cout << "Enter age of staff: ";
	cin >> age;
	obj5.staffDisplay();

	student obj6;
	cout << "Enter name of student: ";
	cin >> name;
	cout << "Enter age of student: ";
	cin >> age;
	obj6.studentDisplay();

	undergraduates obj7;
	cout << "Enter name of ungergraduate: ";
	cin >> name;
	cout << "Enter age of undergraduate: ";
	cin >> age;
	obj7.undergraduateDisplay();

	freshmen obj8;
	cout << "Enter name of freshmen: ";
	cin >> name;
	cout << "Enter age of freshmen: ";
	cin >> age;
	obj8.freshmenDisplay();

	sophomores obj9;
	cout << "Enter name of sophomore: ";
	cin >> name;
	cout << "Enter age of sophomore: ";
	cin >> age;
	obj9.sophomoresDisplay();

	juniors obj10;
	cout << "Enter name of junior: ";
	cin >> name;
	cout << "Enter age of junior: ";
	cin >> age;
	obj10.juniorsDisplay();

	seniors obj11;
	cout << "Enter name of senior: ";
	cin >> name;
	cout << "Enter age of senior: ";
	cin >> age;
	obj11.seniorDisplay();

	graduates obj12;
	cout << "Enter name of graduate: ";
	cin >> name;
	cout << "Enter age of graduate: ";
	cin >> age;
	obj12.graduatesDisplay();

	PHDstudents obj13;
	cout << "Enter name of phd: ";
	cin >> name;
	cout << "Enter age of phd: ";
	cin >> age;
	obj13.phdDisplay();

	mastersStudents obj14;
	cout << "Enter name of master student: ";
	cin >> name;
	cout << "Enter age of master student: ";
	cin >> age;
	obj14.mastersDisplay();

	alumni obj15;
	cout << "Enter name of alumni: ";
	cin >> name;
	cout << "Enter age of alumni: ";
	cin >> age;
	obj15.alumniDisplay();

	return 0;
}