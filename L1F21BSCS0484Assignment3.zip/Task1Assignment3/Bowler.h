#pragma once
#include"Player.h"
class Bowler: public Player
{
protected:
	int No_of_wickets;
private:
	Bowler(int =0);
	~Bowler();
	void display();

};

