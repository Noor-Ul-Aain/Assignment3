#pragma once
#include"Player.h"
using namespace std;
class Batsman:virtual public Player
{
protected:
	int Total_score;
	int* Per_match_score;
	double Average;
public:
	Batsman(int = 0, int* = 0 ,double = 0);
	int gettotalscore();
	int* getpermatchacore();
	int sum();
	double calculateAvg();
	void display();
	~Batsman();
};

