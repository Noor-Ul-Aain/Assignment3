#include "Bowler.h"
#include<iostream>
using namespace std;
Bowler::Bowler(int noofwickets)
{
	No_of_wickets = noofwickets;
}
Bowler::~Bowler()
{
}
void Bowler::display()
{
	this->Player::dispaly();
	cout << "Total No Of Wickets:" << No_of_wickets << endl;
}