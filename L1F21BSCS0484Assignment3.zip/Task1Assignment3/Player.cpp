#include "Player.h"
#include<iostream>
using namespace std;
Player::Player(char* name, int matches)
{
	int length = 0;
	while (true)
	{
		if (name[length] == '\0')
			break;
		else
			length++;
	}

	Name = new char[length + 1];

	for (int i = 0; i < length; i++)
		Name[i] = name[i];

	Name[length] = '\0';
	
	Matches = matches;
}
Player::Player(const Player& OtherObj)
{
	int length = 0;
	while (true)
	{
		if (OtherObj.Name[length] == '\0')
			break;
		else
			length++;
	}

	Name = new char[length + 1];

	for (int i = 0; i < length; i++)
		Name[i] = OtherObj.Name[i];

	Name[length] = '\0';
	Matches = OtherObj.Matches;

}
Player Player::operator=(const Player& OtherObj)
{
	int length = 0;
	while (true)
	{
		if (OtherObj.Name[length] == '\0')
			break;
		else
			length++;
	}

	Name = new char[length + 1];

	for (int i = 0; i < length; i++)
		Name[i] = OtherObj.Name[i];

	Name[length] = '\0';
	Matches = OtherObj.Matches;
	return*this;
}
void Player::dispaly()
{
	cout << "Name " << Name << endl << "Total No. Of Matches " <<Matches<< endl;
}
Player::~Player()
{
	if (Name != nullptr)
	{
		delete[] Name;	
		Name = nullptr;	
	}
	
}

