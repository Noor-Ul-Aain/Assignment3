#pragma once
class Player
{
protected:
	char* Name;
	int Matches;
public:
	
	Player(char* = '\0', int = 0);
	Player(const Player& OtherObj);
	Player operator=(const Player& Otherobj);
	void dispaly();
	~Player();
};

