#include "Batsman.h"
#include<iostream>
using namespace std;
Batsman::Batsman(int totalscore, int* permatchscore, double avg)
{
	Total_score=totalscore;
	Average = avg;
	Per_match_score = new int[10];

}
int Batsman::gettotalscore()
{
	return Total_score;
}
int* Batsman::getpermatchacore()
{

	int* temp = new int[this->Matches + 1];

	for (int i = 0; i < this->Matches; i++)
	{
		temp[i] = Per_match_score[i];

	}
	temp[this->Matches] = '\0';

	return temp;
}
int Batsman::sum()
{
	int add = 0;
	for (int i = 0; i < this->Matches; i++)
	{
		add = add+Per_match_score[i];

	}
	return add;
}
double Batsman::calculateAvg()
{

	Average = sum()/ this->Matches;
	return Average;
}
void Batsman::display()
{
	this->Player::dispaly();
	cout << "Total Score " << Total_score << endl;
	cout << "Score Per Match ";
	for (int i = 0; i < this->Matches; i++) {
		cout << Per_match_score[i] << " ";
	}
	cout << endl;
	cout << "Average Score " << Average << endl;
}