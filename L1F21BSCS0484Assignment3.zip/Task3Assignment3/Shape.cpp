#include "Shape.h"
#include<iostream>
using namespace std;

double Shape::area() const
{
	std::cout << "Shape da area" << std::endl;
	return length * width;
}

double Shape::volume() const
{
	return length * width * height;
}

Shape::Shape(double l, double w, double h)
{
	std::cout << "Shape(double, double, double)" << std::endl;
	length = l;
	width = w;
	height = h;
}

Shape::~Shape()
{
	std::cout << "~Shape()" << std::endl;
}

void Shape::display() const
{
	std::cout << "length = " << length << std::endl;
	std::cout << "width = " << width << std::endl;
	std::cout << "height = " << height << std::endl;
}