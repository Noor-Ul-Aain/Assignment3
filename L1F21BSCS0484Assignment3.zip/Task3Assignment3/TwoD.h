#pragma once
#include "Shape.h"
class TwoD:virtual public Shape
{  
public:
	TwoD(int = 0, int = 0);
	~TwoD();
	void dispaly();
	TwoD(const TwoD& OtherObj);
	TwoD operator=(const TwoD& OtherObj);
};

