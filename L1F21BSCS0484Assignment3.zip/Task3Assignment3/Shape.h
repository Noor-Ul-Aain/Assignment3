#include <iostream>

class Shape
{
protected:
	double length;
	double width;
	double height;
public:
	Shape();
	void display() const;
	double volume() const;
	double area() const;
	Shape(double, double, double);
	~Shape();
};