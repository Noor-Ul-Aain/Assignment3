#pragma once
#include<iostream>
#include"Shape.h"
#include"ThreeD.h"
class Shpare :public ThreeD
{
private:
	double* radius=0;
	const double pi;
public:
	Shpare(int = 0, int = 0);
	~Shpare();
	void display() const;
	double area() const;
	double volume() const;
};
