#include "Circle.h"
using namespace std;
double Circle::area() const
{
	return pi * *radius * *radius;
}

double Circle::getRadius() const
{
	return *radius;
}

void Circle::setRadius(double value)
{
	*radius = value;
	tempVar = 65;
}

void Circle::display() const
{
	cout << "Radius = " << *radius << endl;
	cout << "tempVar = " << tempVar << endl;
	cout << "Pi = " << pi << endl;

}

Circle::Circle(double r) :pi(22.0 / 7)
{
	cout << "Circle(double)" << endl;
	radius = new double;
	*radius = r;
	tempVar = 55;
}


Circle::~Circle()
{
	cout << "~Circle()" << endl;
	delete radius;
	radius = nullptr;
}
