#include "TwoD.h"
#include"Shape.h"
#include<iostream>
using namespace std;
TwoD::TwoD(int len= 0, int wid= 0):Shape(len,wid,0)
{

}
TwoD::~TwoD()
{
}
TwoD::TwoD(const TwoD& OtherObj)
{
	length= OtherObj.length;
	width = OtherObj.width;
}
TwoD TwoD::operator=(const TwoD& OtherObj)
{
	length = OtherObj.length;
	width = OtherObj.width;
	return *this;
}

