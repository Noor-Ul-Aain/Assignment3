#include"Shape.h"
#include"ThreeD.h"
#include<iostream>
using namespace std;
ThreeD::ThreeD(int len = 0, int wid = 0, int hei = 0) :Shape(len, wid, hei)
{

}
ThreeD::~ThreeD()
{
}
ThreeD::ThreeD(const ThreeD& OtherObj)
{
	length = OtherObj.length;
	width = OtherObj.width;
	height = OtherObj.height;
}
ThreeD ThreeD::operator=(const ThreeD & OtherObj)
{
	length = OtherObj.length;
	width = OtherObj.width;
	height = OtherObj.height;
	return *this;
}
#include "ThreeD.h"
