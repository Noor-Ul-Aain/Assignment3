#include "Cube.h"
#include"ThreeD.h"
#include"Shape.h"
using namespace std;
double Cube::area() const
{
	return a * a * 6;
}
Cube::Cube(int A = 0)
{
	a = A;
}
Cube::~Cube()
{
}
void Cube::display()const
{
	cout << "Area of Cube " << area() << endl;
}