#include "Triangle.h"
#include"Shape.h"
#include"TwoD.h"
using namespace std;
double Triangle::area() const
{
	return height * width;
}
void Triangle::display() const
{
	cout << "Triangle Area" << area() << endl;
}
Triangle::Triangle(int l = 0, int w = 0) :Shape(l, w, 0)
{
	length = l;
	width = w;
}
Triangle::~Triangle()
{
}