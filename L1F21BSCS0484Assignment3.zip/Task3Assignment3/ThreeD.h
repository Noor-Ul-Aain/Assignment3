#pragma once
#include"ThreeD.h"
##include "Shape.h"
class ThreeD :virtual public Shape
{
public:
	ThreeD(int = 0, int = 0,int =0);
	~ThreeD();
	void dispaly();
	ThreeD(const ThreeD& OtherObj);
	ThreeD operator=(const ThreeD& OtherObj);
};


