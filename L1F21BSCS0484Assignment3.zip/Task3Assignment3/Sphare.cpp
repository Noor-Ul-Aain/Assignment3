#include"Shape.h"
#include"ThreeD.h"
#include"Sphare.h"
using namespace std;
double Sphare::area() const
{
	return pi * *radius *4;
}

void Sphare::setRadius(double value)
{
	*radius = value;
	tempVar = 65;
}

void Sphare::display() const
{
	cout << "Area " << area() << endl;

}

Sphare::Sphare(double r) :pi(22.0 / 7)
{
	cout << "Circle(double)" << endl;
	radius = new double;
	*radius = r;
	tempVar = 55;
}


Sphare::~Sphare()
{
	cout << "~Sphare()" << endl;
	delete radius;
	radius = nullptr;
}