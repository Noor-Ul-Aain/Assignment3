#pragma once
#include"Shape.h"
#include"ThreeD.h"
class Cube:public ThreeD
{
private:
	int a;
public:
	Cube(int = 0);
	~Cube();
	void display() const;
	double area() const;
};

