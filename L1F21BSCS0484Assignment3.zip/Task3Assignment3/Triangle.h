#pragma once
#include"Shape.h"
#include"TwoD.h"
class Triangle:public TwoD
{
public:
	Triangle(int = 0, int = 0);
	~Triangle();
	void display() const;
	double area() const;
	double volume() const;
};

