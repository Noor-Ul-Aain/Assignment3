#pragma once
#include"TwoD.h"
class Square:public TwoD
{
public:
	Square(int = 0, int = 0);
	~Square();
	void display() const;
	double area() const;
	double volume() const;
};

