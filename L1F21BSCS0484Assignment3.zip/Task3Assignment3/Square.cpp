#include "Square.h"
#include"Shape.h"
#include"TwoD.h"
using namespace std;
double Square::area() const
{
	return length*width;
}
void Square::display() const
{
	cout << "Square Area" << area() << endl;
}
Square::Square(int l = 0, int w = 0):Shape(l,w,0)
{
	length = l;
	width = w;
}
Square::~Square()
{
}