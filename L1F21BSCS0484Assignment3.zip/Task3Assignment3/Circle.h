#pragma once
#include"TwoD.h"
class Circle:public TwoD
{
		int tempVar;
		double* radius;
		const double pi;
	public:
		void setRadius(double);
		Circle(double r = 0);
		~Circle();


		void display() const;
		double area() const;
		double getRadius() const;



};

